"use client"

import { useEffect, useRef } from "react"

const Background = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    let animationFrameId: number
    let mouseX = 0
    let mouseY = 0
    let time = 0

    interface Cell {
      x: number
      y: number
      width: number
      height: number
      targetX: number
      targetY: number
      colorOffset: number
      brightness: number
      velocityX: number
      velocityY: number
    }

    const cells: Cell[] = []

    // Define gradient colors
    const colors = [
      { r: 147, g: 51, b: 234 }, // Purple (from-purple-600)
      { r: 59, g: 130, b: 246 }, // Blue (to-blue-500)
    ]

    const isFinite = (value: number): boolean => {
      return typeof value === "number" && Number.isFinite(value)
    }

    const init = () => {
      canvas.width = window.innerWidth
      canvas.height = window.innerHeight

      // Set fixed dimensions for all cells
      const cellWidth = 60
      const cellHeight = 30

      // Reduce the number of cells
      const cellCount = 45

      for (let i = 0; i < cellCount; i++) {
        const x = Math.random() * canvas.width
        const y = Math.random() * canvas.height
        cells.push({
          x,
          y,
          width: cellWidth,
          height: cellHeight,
          targetX: x,
          targetY: y,
          colorOffset: Math.random(),
          brightness: Math.random() * 0.5 + 0.5,
          velocityX: (Math.random() - 0.5) * 4 * 0.75, // Reduced to 3/4 of the original speed
          velocityY: (Math.random() - 0.5) * 4 * 0.75, // Reduced to 3/4 of the original speed
        })
      }
    }

    const getColor = (offset: number) => {
      const t = offset % 1
      const color1 = colors[0]
      const color2 = colors[1]

      return {
        r: Math.floor(color1.r * (1 - t) + color2.r * t),
        g: Math.floor(color1.g * (1 - t) + color2.g * t),
        b: Math.floor(color1.b * (1 - t) + color2.b * t),
      }
    }

    const checkCollision = (cell1: Cell, cell2: Cell) => {
      return (
        cell1.x < cell2.x + cell2.width &&
        cell1.x + cell1.width > cell2.x &&
        cell1.y < cell2.y + cell2.height &&
        cell1.y + cell1.height > cell2.y
      )
    }

    const resolveCollision = (cell1: Cell, cell2: Cell) => {
      const dx = cell2.x - cell1.x
      const dy = cell2.y - cell1.y
      const distance = Math.sqrt(dx * dx + dy * dy)

      // Calculate normal vector
      const nx = dx / distance
      const ny = dy / distance

      // Calculate relative velocity
      const vx = cell1.velocityX - cell2.velocityX
      const vy = cell1.velocityY - cell2.velocityY

      // Calculate dot product
      const dotProduct = vx * nx + vy * ny

      // Don't resolve collision if objects are moving away from each other
      if (dotProduct > 0) return

      // Calculate impulse
      const impulse = (-2 * dotProduct) / 2 // Assuming equal mass for all cells

      // Apply impulse
      cell1.velocityX -= impulse * nx
      cell1.velocityY -= impulse * ny
      cell2.velocityX += impulse * nx
      cell2.velocityY += impulse * ny

      // Separate the cells to prevent overlap
      const overlap = 0.5 * (cell1.width + cell2.width - Math.abs(dx))
      cell1.x -= (overlap * nx) / 2
      cell1.y -= (overlap * ny) / 2
      cell2.x += (overlap * nx) / 2
      cell2.y += (overlap * ny) / 2
    }

    const animate = () => {
      try {
        ctx.fillStyle = "rgba(0, 0, 0, 0.1)" // Add slight trail effect
        ctx.fillRect(0, 0, canvas.width, canvas.height)

        cells.forEach((cell, index) => {
          // Update cell position based on velocity
          cell.x += cell.velocityX * 0.75 // Reduced to 3/4 of the original speed
          cell.y += cell.velocityY * 0.75 // Reduced to 3/4 of the original speed

          // Add random acceleration for more chaotic movement (reduced to 3/4)
          cell.velocityX += (Math.random() - 0.5) * 0.15
          cell.velocityY += (Math.random() - 0.5) * 0.15

          // Limit maximum velocity (reduced to 3/4)
          const maxVelocity = 4.5 // Reduced from 6
          const speed = Math.sqrt(cell.velocityX * cell.velocityX + cell.velocityY * cell.velocityY)
          if (speed > maxVelocity) {
            cell.velocityX = (cell.velocityX / speed) * maxVelocity
            cell.velocityY = (cell.velocityY / speed) * maxVelocity
          }

          // Check for collisions with other cells
          for (let i = index + 1; i < cells.length; i++) {
            if (checkCollision(cell, cells[i])) {
              resolveCollision(cell, cells[i])
            }
          }

          // Calculate distance from mouse
          const dx = mouseX - cell.x
          const dy = mouseY - cell.y
          const distance = Math.sqrt(dx * dx + dy * dy)

          if (isFinite(distance) && distance > 0) {
            const maxDistance = 150
            const force = Math.min(1, (1 - distance / maxDistance) * 0.05)

            if (distance < maxDistance) {
              // Calculate repulsion direction
              const repulsionAngle = Math.atan2(dy, dx)
              cell.velocityX -= Math.cos(repulsionAngle) * force * 1.5 // Reduced from 2
              cell.velocityY -= Math.sin(repulsionAngle) * force * 1.5 // Reduced from 2
            }
          }

          // Wrap around screen edges
          if (cell.x + cell.width < 0) cell.x = canvas.width
          if (cell.x > canvas.width) cell.x = -cell.width
          if (cell.y + cell.height < 0) cell.y = canvas.height
          if (cell.y > canvas.height) cell.y = -cell.height

          const color = getColor(cell.colorOffset + time * 0.05)

          if (isFinite(cell.x) && isFinite(cell.y)) {
            const gradient = ctx.createLinearGradient(cell.x, cell.y, cell.x + cell.width, cell.y + cell.height)

            gradient.addColorStop(0, `rgba(${color.r}, ${color.g}, ${color.b}, ${cell.brightness * 0.7})`)
            gradient.addColorStop(1, `rgba(${color.r}, ${color.g}, ${color.b}, ${cell.brightness * 0.3})`)

            ctx.beginPath()
            ctx.fillStyle = gradient
            ctx.fillRect(cell.x, cell.y, cell.width, cell.height)

            // Add a subtle border to the cell
            ctx.strokeStyle = `rgba(255, 255, 255, ${cell.brightness * 0.5})`
            ctx.lineWidth = 1
            ctx.strokeRect(cell.x, cell.y, cell.width, cell.height)
          }
        })

        time += 0.00075 // Reduced from 0.001
        animationFrameId = requestAnimationFrame(animate)
      } catch (error) {
        console.error("Animation error:", error)
        cancelAnimationFrame(animationFrameId)
      }
    }

    const handleMouseMove = (event: MouseEvent) => {
      mouseX = event.clientX
      mouseY = event.clientY
    }

    const handleResize = () => {
      init()
    }

    init()
    animate()

    window.addEventListener("mousemove", handleMouseMove)
    window.addEventListener("resize", handleResize)

    return () => {
      cancelAnimationFrame(animationFrameId)
      window.removeEventListener("mousemove", handleMouseMove)
      window.removeEventListener("resize", handleResize)
    }
  }, [])

  return (
    <canvas
      ref={canvasRef}
      className="fixed inset-0 w-full h-full pointer-events-none"
      style={{ background: "black" }}
    />
  )
}

export default Background

