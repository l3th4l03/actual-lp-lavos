"use client"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { ArrowRight, Play } from "lucide-react"
import Background from "./components/background"

const Logo = () => (
  <div className="relative w-12 h-12">
    <svg viewBox="0 0 640 640" className="w-full h-12 text-white" fill="currentColor">
      <path d="M320 40C166.288 40 40 166.288 40 320s126.288 280 280 280 280-126.288 280-280S473.712 40 320 40zm0 70c116.026 0 210 93.974 210 210s-93.974 210-210 210S110 436.026 110 320 203.974 110 320 110zm0 70c-77.32 0-140 62.68-140 140s62.68 140 140 140 140-62.68 140-140-62.68-140-140-140z" />
    </svg>
  </div>
)

export default function LandingPage() {
  return (
    <div className="min-h-screen bg-black text-white overflow-hidden relative">
      <Background />

      {/* Top Navigation */}
      <nav className="absolute top-0 w-full z-50 flex justify-between items-center p-6">
        <div className="flex items-center gap-3">
          <Logo />
          <span className="font-medium text-xl text-lime-400">Lavos AI</span>
        </div>
        <div className="flex items-center gap-4">
          <Button variant="ghost" className="text-sm hover:bg-white/5">
            <span className="text-lime-400">
              <Play className="w-4 h-4 mr-2 inline text-lime-400" />
              Watch the demo
            </span>
          </Button>
        </div>
      </nav>

      {/* Main Content */}
      <main className="flex flex-col items-center justify-center min-h-screen relative z-10 px-4">
        <div className="max-w-4xl mx-auto text-center space-y-8">
          <h1 className="text-5xl sm:text-7xl font-bold tracking-tight leading-tight text-lime-400">
            Supercharge your
            <br />
            spreadsheets.
          </h1>

          <div className="flex items-center justify-center gap-2 text-base text-lime-400 font-medium">
            <span className="size-2.5 rounded-full bg-lime-400"></span>
            Available Soon
          </div>

          <div className="max-w-xl mx-auto space-y-4">
            <h2 className="text-2xl text-lime-400">Join the waitlist!</h2>
            <div className="flex gap-2 p-1 bg-white/5 rounded-lg backdrop-blur-sm">
              <Input
                type="email"
                placeholder="Enter your email..."
                className="border-0 bg-transparent text-white placeholder:text-gray-500"
              />
              <Button className="bg-gradient-to-r from-purple-600 to-blue-500 hover:from-purple-700 hover:to-blue-600 transition-all duration-200 px-4 py-2">
                <span className="text-lime-400 font-semibold text-sm flex items-center">
                  Join
                  <ArrowRight className="w-4 h-4 ml-2" />
                </span>
              </Button>
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}

